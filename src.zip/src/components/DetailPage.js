// DetailPage.js
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';

const DetailPage = () => {
    const { id } = useParams();
    const [parcel, setParcel] = useState(null);

    useEffect(() => {
        const fetchParcel = async () => {
            try {
                const response = await fetch(`https://67296bac6d5fa4901b6d14a6.mockapi.io/oss4-2/parcels/${id}`);
                const data = await response.json();
                setParcel(data);
            } catch (error) {
                console.error('Error fetching parcel:', error);
            }
        };

        fetchParcel();
    }, [id]);

    if (!parcel) {
        return <div>Loading...</div>;
    }

    return (
        <div className="detail-page">
            <h2>Parcel Detail</h2>
            <p><strong>운송장 번호:</strong> {parcel.tracking_number}</p>
            <p><strong>보내는 사람:</strong> {parcel.sender_name}</p>
            <p><strong>받는 사람:</strong> {parcel.recipient_name}</p>
            <p><strong>주소:</strong> {parcel.recipient_address}</p>
            <p><strong>상태:</strong> {parcel.status}</p>
            <p><strong>비용:</strong> {parcel.cost}원</p>
        </div>
    );
};

export default DetailPage;
